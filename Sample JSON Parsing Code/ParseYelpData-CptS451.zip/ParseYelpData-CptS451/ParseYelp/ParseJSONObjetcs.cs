﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Json;
using System.Text.RegularExpressions;

namespace parse_yelp
{
    
    class ParseJSONObjects
    {              

        public ParseJSONObjects( )
        {
        }
        
        public void Close( )
        {
        }


        private string cleanTextforSQL(string inStr)
        {
            String outStr = Encoding.GetEncoding("iso-8859-1").GetString(Encoding.UTF8.GetBytes(inStr));
            outStr = outStr.Replace("\"", "").Replace("'", " ").Replace(@"\n", " ").Replace(@"\u000a", " ").Replace("\\", " ").Replace("é", "e").Replace("ê", "e").Replace("Ã¼", "A").Replace("Ã", "A").Replace("¤", "").Replace("©", "c").Replace("¶","");
            outStr = Regex.Replace(outStr,@"[^\u0020-\u007E]", "?");         
            return outStr;
        }

    
        
        /* Extract business information*/
        public string ProcessBusiness(JsonObject my_jsonStr)
        {            
            //You may extract values for certain keys by specifying the key name. 
            //Example: extract business_id
            String business_id = my_jsonStr["business_id"].ToString();
                        
            /*To retrieve list of Keys in JSON :
                    my_jsonStr.Keys.ToArray()[0]  is the "business_id" key. */
            /*To retrieve list of Values in JSON 
                    my_jsonStr.Values.ToArray()[0]  is the value for "business_id".*/
            
            //Alternative ways to extract business_id:
            business_id = my_jsonStr[my_jsonStr.Keys.ToArray()[0]].ToString();
            business_id = my_jsonStr.Values.ToArray()[0].ToString();

            /* EXTRACT OTHER KEY VALUES */

            //Clean text and remove any characters that might cause errors in PostgreSQL.
            String business_data =
                    cleanTextforSQL(business_id) + "\t" +
                    cleanTextforSQL(my_jsonStr["name"].ToString()) + "\t" +
                    cleanTextforSQL(my_jsonStr["full_address"].ToString()) + "\t" +
                    cleanTextforSQL(my_jsonStr["state"].ToString()) + "\t" +
                    cleanTextforSQL(my_jsonStr["city"].ToString()) + "\t" +
                    my_jsonStr["latitude"].ToString() + "\t" +
                    my_jsonStr["longitude"].ToString() + "\t" +
                    my_jsonStr["stars"].ToString() + "\t" +
                    my_jsonStr["review_count"].ToString() + "\t" +
                    my_jsonStr["open"].ToString() + "\t[";
            JsonArray categories = (JsonArray)my_jsonStr["categories"];
            for(int i=0; i<categories.Count; i++){
                business_data = business_data + cleanTextforSQL(categories[i].ToString()) + ","; 
            }
            business_data = business_data + "]\n";

            return business_data;
            
        } 

        /* Extract user information*/
        public string ProcessUsers(JsonObject my_jsonStr)
        {
            //Example: extract user_id
            String user_id = cleanTextforSQL(my_jsonStr["user_id"].ToString());
            /* EXTRACT OTHER KEY VALUES */

            return (user_id );
        }

        /* Extract tips information*/
        public string ProcessTips(JsonObject my_jsonStr)
        {
            //Example: extract business_id
            String business_id = cleanTextforSQL(my_jsonStr["business_id"].ToString());
            /* EXTRACT OTHER KEY VALUES */

            return (business_id);
        }

        /* Extract checkin information*/
        public string ProcessCheckin(JsonObject my_jsonStr)
        {
            //Example: extract business_id
            String business_id = cleanTextforSQL(my_jsonStr["business_id"].ToString());
            /* EXTRACT OTHER KEY VALUES */

            return (business_id);
        }
                              

    }
}
